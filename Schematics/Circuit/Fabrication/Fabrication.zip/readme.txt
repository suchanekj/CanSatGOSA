1. Name: Jakub Suchanek

   Phone #: +420 602 546 699

2. Company:

3. Billing address:
	Tovarni 549,
	252 43, Pruhonice
	Czech Republic

4. Shipping address:
	Tovarni 549,
	252 43, Pruhonice
	Czech Republic

5. Shipping option: TNT Express air service

6. Order: DSS 1 piece, panelization (8x arm, 2x main, 2x top as per Panelization.png), no silkscreen, 0.8 mm thick

7. We do not have valid EU VAT ID.
   
8. Mastercard

9. Guilotinee

10. I used 1.006 mm vias as they provide the 0.203 border (I believe your FAQ has a typo when saying you need 1.06 mm).